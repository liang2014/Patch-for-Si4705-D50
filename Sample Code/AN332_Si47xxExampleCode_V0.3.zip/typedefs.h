#define u32 unsigned long
#define u16 unsigned int
#define u8  unsigned char
#define i8  char
