/***************************************************************************************
                  Silicon Laboratories Broadcast Si47XX Example Code

   EVALUATION AND USE OF THIS SOFTWARE IS SUBJECT TO THE TERMS AND CONDITIONS OF
     THE SOFTWARE LICENSE AGREEMENT IN THE DOCUMENTATION FILE CORRESPONDING
     TO THIS SOURCE FILE.
   IF YOU DO NOT AGREE TO THE LIMITED LICENSE AND CONDITIONS OF SUCH AGREEMENT,
     PLEASE RETURN ALL SOURCE FILES TO SILICON LABORATORIES.

  (C) Copyright 2014, Silicon Laboratories, Inc. All rights reserved.
****************************************************************************************/
//-----------------------------------------------------------------------------
//
// WBRXtest.h
//
// Contains the function prototypes for the functions contained in WBRXtest.c
//
//-----------------------------------------------------------------------------
#ifndef _WBRXTEST_H_
#define _WBRXTEST_H_

//-----------------------------------------------------------------------------
// Defines
//-----------------------------------------------------------------------------
#define DEMO_DELAY 5000

//-----------------------------------------------------------------------------
// Globals
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Function prototypes
//-----------------------------------------------------------------------------
void test_WBRXtune(void);
void test_WBRXvolume(void);
void test_WBRXpowerCycle(void);
void test_WBRX_scan(void);
void test_WBRXsame(void);

#endif
