/***************************************************************************************
                  Silicon Laboratories Broadcast Si47XX Example Code

   EVALUATION AND USE OF THIS SOFTWARE IS SUBJECT TO THE TERMS AND CONDITIONS OF
     THE SOFTWARE LICENSE AGREEMENT IN THE DOCUMENTATION FILE CORRESPONDING
     TO THIS SOURCE FILE.
   IF YOU DO NOT AGREE TO THE LIMITED LICENSE AND CONDITIONS OF SUCH AGREEMENT,
     PLEASE RETURN ALL SOURCE FILES TO SILICON LABORATORIES.

  (C) Copyright 2014, Silicon Laboratories, Inc. All rights reserved.
****************************************************************************************/
//-----------------------------------------------------------------------------
//
// AMRXtest.h
//
// Contains the function prototypes for the functions contained in AMRXtest.c
//
//-----------------------------------------------------------------------------
#ifndef _AMRXTEST_H_
#define _AMRXTEST_H_

//-----------------------------------------------------------------------------
// Defines
//-----------------------------------------------------------------------------
#define DEMO_DELAY 5000

//-----------------------------------------------------------------------------
// Globals
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Function prototypes
//-----------------------------------------------------------------------------
void test_AMRXtune(void);
void test_AMSWLWRXtune(void);
void test_AMRXautoseek(void);
void test_AMRXvolume(void);
void test_AMRXpowerCycle(void);

#endif
